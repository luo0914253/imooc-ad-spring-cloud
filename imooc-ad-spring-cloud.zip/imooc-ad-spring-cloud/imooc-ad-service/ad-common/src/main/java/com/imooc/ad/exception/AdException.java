package com.imooc.ad.exception;

public class AdException extends Exception {
    public AdException(String message) {
        super(message);
    }
}
